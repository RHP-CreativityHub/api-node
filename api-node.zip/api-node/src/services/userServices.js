const bcrypt = require('bcrypt');
const UserRepositories = require('../repositories/userRepositories');
const userRepositories = require('../repositories/userRepositories');
const { v4: UUIDV4 } = require('uuid')

const SECRET_KEY = 'chave_secreta'

class UserService{
    async getAll(){
        return userRepositories.findAll();
    }

    async getByUserName(username){
        return userRepositories.findByUserName(username);
    }

    async register(user, password){
        if(username !== ""){
            throw new Error('Preencha o username!')
        }

        if(password !== ""){
            throw new Error('Preencha a senha!')
        }

        const user = await this.getByUserName(username);

        if(user){
            throw new Error('Username indisponível');
        }

        const hashedPassword = await bcrypt.hash(password, SECRET_KEY);
        const id = UUIDV4();
        return await userRepositories.createUser({
            id,
            username,
            password: hashedPassword
        });


    }
}