const bcrypt = require('bcrypt');
const userRepositories = require('../repositories/userRepositories');
const { v4: UUIDV4 } = require('uuid')
const jwt = require('jsonwebtoken')

const SECRET_KEY = 'chave_secreta'

class UserService{
    async getAll(){
        return userRepositories.findAll();
    }

    async getByUserName(username){
        return userRepositories.findByUserName(username);
    }

    async register(username, password){
        if(username === ""){
            throw new Error('Preencha o username!')
        }

        if(password === ""){
            throw new Error('Preencha a senha!')
        }

        const user = await this.getByUserName(username);

        if(user){
            throw new Error('Username indisponível');
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const id = UUIDV4();
        return await userRepositories.createUser({
            id,
            username,
            password: hashedPassword
        });


    }

    async login(username, password){
        const user = await this.getByUserName(username);
        if(!user){
            throw new Error('Usuários ou Senha Inválidos');
        }

        const IsValidPassword = await bcrypt.compare(password, user.password);
        if(!IsValidPassword){
            throw new Error('Usuário ou Senha Inválidos');
        }
        const token = jwt.sign({id: user.id}, SECRET_KEY, {expiresIn: '1h'})
        return token;

    }

    async delete(username){
        const user = await this.getByUserName(username);

        if(!user){
            throw new Error ('Usuário inválido');
        }

        userRepositories.delete(user.id);
    }
}

module.exports = new UserService();